#' Plot a Histogram with Automatic Binning and Labels
#'
#' @param data A data frame.
#' @param var A numeric column from the data frame.
#' @return A ggplot2 histogram with auto labels and custom theme.
#' @export
plot_histogram_auto <- function(data, var) {
  var_name <- deparse(substitute(var))
  ggplot(data, aes(x = {{ var }})) +
    geom_histogram(bins = 30, fill = "#0073C2FF", color = "white") +
    labs(title = paste("Histogram of", var_name),
         x = var_name,
         y = "Count") +
    theme_humphreys()
}

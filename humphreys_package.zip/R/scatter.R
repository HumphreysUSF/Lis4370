#' Scatter Plot with Auto Labels and Linear Trend
#'
#' @param data A data frame.
#' @param x Independent variable.
#' @param y Dependent variable.
#' @return A scatter plot with labels and a linear fit line.
#' @export
plot_scatter_labeled <- function(data, x, y) {
  x_name <- deparse(substitute(x))
  y_name <- deparse(substitute(y))
  ggplot(data, aes(x = {{ x }}, y = {{ y }})) +
    geom_point(color = "#E64B35FF") +
    geom_smooth(method = "lm", se = FALSE, linetype = "dashed") +
    labs(title = paste("Scatterplot of", y_name, "vs", x_name),
         x = x_name,
         y = y_name) +
    theme_humphreys()
}

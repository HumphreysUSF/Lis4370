#' Custom Humphreys ggplot2 Theme
#'
#' @return A ggplot2 theme with soft grid lines and modern font.
#' @export
theme_humphreys <- function() {
  theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      axis.title = element_text(size = 12),
      panel.grid.major = element_line(color = "grey80"),
      panel.grid.minor = element_blank()
    )
}

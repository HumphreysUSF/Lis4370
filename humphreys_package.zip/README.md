# humphreys

The `humphreys` R package is a lightweight toolkit for producing elegant and easy-to-read `ggplot2` visualizations. This package includes functions for plotting histograms, labeled scatter plots, and a custom minimalist theme.

## Installation

```r
# install devtools if needed
install.packages("devtools")
devtools::install_github("yourusername/humphreys")
```

## Functions

- `plot_histogram_auto(data, var)` – Histogram with smart bins and title.
- `plot_scatter_labeled(data, x, y)` – Scatterplot with trend line and labels.
- `theme_humphreys()` – Clean theme with modern visual design.

## Example

```r
library(humphreys)
library(ggplot2)

plot_histogram_auto(mtcars, mpg)
plot_scatter_labeled(mtcars, wt, mpg)
```

## License

MIT
